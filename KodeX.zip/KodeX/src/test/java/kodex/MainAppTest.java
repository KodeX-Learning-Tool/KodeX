package kodex;

import org.junit.jupiter.api.Test;

class MainAppTest {

  @Test
  void test() {
    //TODO: Not yet implemented
  }
}
